module.exports = {
    database: 'mongodb://twadmin:C0mplexPwd@ds123718.mlab.com:23718/itunes-db',
    port: 3030,
    secret: 'jintotw_pwa_1234',
    itunesApi: 'https://itunes.apple.com/search'
};

export default {
  data: {},
  status: 'init'
};


import 'babel-polyfill';
import App from './components/App';

new App().render();

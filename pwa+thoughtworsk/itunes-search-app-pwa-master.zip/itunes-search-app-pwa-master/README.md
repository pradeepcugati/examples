# itunes-search-app-pwa
iTunes search app with PWA compliance

## Pre-requisite
[Node](https://nodejs.org/en/)
[Yarn](https://yarnpkg.com/en/)
We are using node v8.9

## To run application
- nvm use (If you are using nvm to manage node version)
- yarn install
- yarn start (To start the application)

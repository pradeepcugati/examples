export default {
  data: {},
  status: 'init',
  activeView: 'search',
  isLoggedIn: false,
  isGuest: true,
  email: 'Guest'
};

